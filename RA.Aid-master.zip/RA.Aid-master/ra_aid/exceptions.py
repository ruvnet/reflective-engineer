class TaskCompletedException(Exception):
    """Raised when a one-shot task has been completed."""
    pass
